package com.cg.capbook.services;

import com.cg.capbook.beans.Persons;

public interface CapBookServices {
public String acceptPersonDetails(Persons persons);
public Persons getPersonDetails(String emailId) throws Exception;
public Persons setPassword(Persons persons);
}

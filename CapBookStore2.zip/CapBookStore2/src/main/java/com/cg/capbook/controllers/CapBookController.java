package com.cg.capbook.controllers;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;


import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.beans.Persons;
import com.cg.capbook.exceptions.BillDetailsNotFoundException;
import com.cg.capbook.exceptions.BillingServicesDownException;
import com.cg.capbook.exceptions.CustomerDetailsNotFoundException;
import com.cg.capbook.exceptions.InvalidBillMonthException;
import com.cg.capbook.exceptions.PlanDetailsNotFoundException;
import com.cg.capbook.exceptions.PostpaidAccountNotFoundException;
import com.cg.capbook.services.CapBookServices;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
@Controller
public class CapBookController {
	private static final Object repeatPersonPassword = null;
	@Autowired
	private CapBookServices capBookServices;
	Persons persons;
	@RequestMapping("/registrationDa")
	public ModelAndView registerPersonAction(@ModelAttribute Persons persons) {
		String personId=capBookServices.acceptPersonDetails(persons);
		return new ModelAndView("index","persons",persons);
	}
	@RequestMapping("/personLogin")
	public ModelAndView completeRegistrationUsingGeneratedCode(@RequestParam("personEmailId") String personEmailId,@RequestParam("personPassword") String personPassword) throws Exception  {
		Persons persons = capBookServices.getPersonDetails(personEmailId);
		if(persons.getPersonPassword().equals(personPassword))
		return new ModelAndView("profilePage","persons",persons);
		
		else
			return new ModelAndView("registrationSuccess","persons",persons);
	}
	
	@RequestMapping("/passwordReset")
	public ModelAndView passwordResetGeneratedCode(@RequestParam("personEmailId") String personEmailId,@RequestParam("securityAnswer") String securityAnswer) throws Exception  {
		Persons persons = capBookServices.getPersonDetails(personEmailId);
		if(persons.getSecurityAnswer().equalsIgnoreCase(securityAnswer))
		return new ModelAndView("newPassword","persons",persons);
		
		else
			return new ModelAndView("registrationSuccess","persons",persons);
	}
	
	@RequestMapping("/setPassword")
	public ModelAndView passwordSetGeneratedCode(@RequestParam("personEmailId") String personEmailId,@RequestParam("personPassword") String personPassword,@RequestParam("repeatPersonPassword") String repeatPersonPassword) throws Exception  {
		Persons persons=capBookServices.getPersonDetails(personEmailId);
		//persons=capBookServices.getPersonDetails(persons.getPersonEmailId());
		if(repeatPersonPassword.equals(personPassword)) {
			persons.setPersonPassword(personPassword);
			persons.setRepeatPersonPassword(repeatPersonPassword);
		persons=capBookServices.setPassword(persons);
		return new ModelAndView("index","persons",persons);
		}
		else
			return new ModelAndView("registrationSuccess","persons",persons);
	}
	
	
}